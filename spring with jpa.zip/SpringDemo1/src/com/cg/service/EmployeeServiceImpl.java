package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.dao.IEmployeeRepositary;
import com.cg.entities.Employee;
@Service
@Transactional  
public class EmployeeServiceImpl implements IEmployeeService{

	
	@Autowired
	private IEmployeeRepositary employeeRepositary;
	
	
	
	@Override
	public Employee save(Employee employee) {
		return employeeRepositary.save(employee);
		
	}

	@Override
	public List<Employee> loadAll() {
		// TODO Auto-generated method stub
		return employeeRepositary.loadAll();
		
	}

}
